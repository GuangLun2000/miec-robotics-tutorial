#include<iostream>
using namespace std;

int main(){
    // int num = 33;
    cout << "a:";
    for (int i = 33; i >= 3; i=i-3)
    {
        cout  << i << " ";
    }
    cout << endl;
    cout << "b:";
    char c;
    for(c='Z'; c>='A'; c--){
        cout << c << " ";
    }
    cout << endl;
    return 0;
}
//This code is created by Hanlin Cai
//MU  number : 20122161
//FZU number : 832002117