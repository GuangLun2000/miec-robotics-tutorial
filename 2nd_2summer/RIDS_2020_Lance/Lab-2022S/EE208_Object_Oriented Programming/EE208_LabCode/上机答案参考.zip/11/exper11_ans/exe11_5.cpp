
#include<iostream>

using namespace std;

int main() {
    cout << 10 / 5.0 << endl;
    return 0;
}
