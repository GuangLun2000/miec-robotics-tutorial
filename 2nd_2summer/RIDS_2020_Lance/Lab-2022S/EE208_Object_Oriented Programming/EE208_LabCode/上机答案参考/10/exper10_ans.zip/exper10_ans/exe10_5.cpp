

#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
int main()
{
    string s;
    cin >> s;

    vector<int> vis(26), num(26);
    for (char ch : s) {
        num[ch - 'a']++;
    }

    string stk;
    for (char ch : s) {
        if (!vis[ch - 'a']) {
            while (!stk.empty() && stk.back() > ch) {
                if (num[stk.back() - 'a'] > 0) {
                    vis[stk.back() - 'a'] = 0;
                    stk.pop_back();
                } else {
                    break;
                }
            }
            vis[ch - 'a'] = 1;
            stk.push_back(ch);
        }
        num[ch - 'a'] -= 1;
    }
    cout << stk << endl;
}

