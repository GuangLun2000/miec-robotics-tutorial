
#include <iostream>
#include <string>
using namespace std;
int main() {
	int n;
	cin >> n;
    if (n == 0) cout << false << endl;
    long x = n;
    cout << (x & (x - 1)) == 0 << endl;
}
