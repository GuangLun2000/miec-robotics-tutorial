#include <iostream>
#include <string>

using namespace std;

string compression(const string &str) {
    int N = str.size();
    string ret;
    ret[0] = str[0];

    for (int j = 0; j < N; j++) {
        int tmp = 1;
        while (str[j] == str[j + 1] && j < N - 1) {
            tmp++;
            j++;
        }
        ret.push_back(str[j]);
        ret.push_back(tmp + '0');
    }

    return ret;
}


int main() {
    string s = "aabcccccaaa";
    cout << "The compressed string is " << compression(s) << endl;

    return 0;
}
