#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int main(){
    string firstName,lastName;
    cout << "Please enter your name : " ;
    cin >> firstName >> lastName;
    cout << lastName << " " << firstName << " " << endl;
    return 0;

}
//This code is created by Hanlin Cai
//MU  number : 20122161
//FZU number : 832002117