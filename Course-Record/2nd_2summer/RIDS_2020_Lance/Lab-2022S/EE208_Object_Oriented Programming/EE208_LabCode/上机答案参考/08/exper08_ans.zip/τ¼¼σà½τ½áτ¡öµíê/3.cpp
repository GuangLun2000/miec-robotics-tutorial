#include<iostream>
#include<fstream>
using namespace std;
void printLine(ifstream& f, int num){
	string s;
	for(int i = 1; i <= num; i++){
		getline(f,s);
	}
	cout << s;
}
int main(){
	ifstream f("test.dat");
	int line_num = 3;
	if(!f){
		cout <<"�ļ���ʧ��" <<endl;
	}
	printLine(f,line_num);
	f.close();
	return 0;
}
