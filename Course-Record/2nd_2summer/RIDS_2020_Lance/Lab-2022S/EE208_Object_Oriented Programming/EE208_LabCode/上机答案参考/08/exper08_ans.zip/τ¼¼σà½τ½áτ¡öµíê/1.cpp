#include<iostream>
#include<fstream>
using namespace std;
int main(){
	fstream ifile;
	ifile.open("test.dat",ios::in);
	ifile.close();
	return 0;
} 
