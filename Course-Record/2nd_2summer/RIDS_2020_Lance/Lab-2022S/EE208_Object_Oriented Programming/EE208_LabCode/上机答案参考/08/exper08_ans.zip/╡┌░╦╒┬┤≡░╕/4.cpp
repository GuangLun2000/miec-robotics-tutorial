#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main(){
	int T;
	cout << "Input  number of cities:";
	cin >> T;
	ofstream ofile("city.dat");
	for(int i = 0; i < T; i++){
		string str;
		cin >> str;
		str  = str + "\n";
		ofile << str;
	}
	ofile.close();
	ifstream ifile("city.dat");
	string strarr[T];
	for(int i = 0; i < T; i++){
		getline(ifile,strarr[i]);
	}
	ifile.close();
	
	for (int i = 0; i < T-1; i++){
		for (int j = i; j < T-1; j++){
			if (strarr[j] > strarr[j+1]) swap(strarr[j],strarr[j+1]);
		}
	}
	
	for (int i = 0; i < T; i++){
		cout << strarr[i] << endl;
	}
	
	
	return 0;
}
