#include<iostream>
#include <fstream>
#include<string>
using namespace std;

char getSecondC(char* filename){
	ifstream file(filename);
	string s;
	file >> s;
	return s[1];
}

int main(){
	cout << getSecondC("test.dat");
	return 0;
} 
