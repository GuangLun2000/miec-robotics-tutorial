#include<iostream>
#include<fstream>
using namespace std;
int main(){
	int arr[20];
	string data = "5 96 87 78 93 21 4 92 82 85 87 6 72 69 85 75 81 73";
	ofstream ofile("data.dat");
	if(!ofile){
		cout << "�ļ���ʧ��" << endl; 
	}
	ofile << data;
	ofile.close();
	int T;
	ifstream ifile("data.dat");
	int len = 0;
	int avg = 0;
	int temp = 0;
	ifile >> T;
	while(!ifile.eof()){
		for(int i = 0; i < T; i++){
			ifile >> temp;
			avg += temp;
		}
		avg = avg/T;
		cout << avg << endl;;
		ifile >> T;
	}
	ifile.close();
	return 0;
}
