/**
 * Write a C++ program that counts the number of words in a string. A word is encountered
 * whenever a transition from a blank space to a nonblank character is encountered. The
 * string contains only words separated by blank spaces.
 */

#include <iostream>
using namespace std;
int main() {
	char string[100];
	int num = 0, word = 0;
	char c;
	// get a string (as an array of characters)
	cout << "please input a string:" << endl;
	gets(string);
	// count words
	for(int i = 0; (c=string[i])!='\0' ; i++) {
		if(c == ' ')
			word = 0;
		else if(word == 0) {
			word = 1;
			num++;
		}
	}
	cout << "there are " << num << " words in the string" << endl;
	return 0;
}
