/**
 * Write a C++ program that accepts both a string and a single character from the user.
 * The program should determine how many times the character is contained in the string.
 * (Hint: Search the string by using the find(str, ind) function. This function should
 * be used in a loop that starts the index value at 0 and then changes the index value
 * to 1 past the index of where the char was last found.)
 */

#include<iostream>
#include<string>
using namespace std;
int main() {
	string str;
	char c;
	// input a string
	cout << "please input a string" << endl;
	cin >> str;
	// input a single character
	cout<< "please input a single character" << endl;
	cin >> c;

	int position = 0;
	int i = 1;
	// loop with the find(str, ind) function
	while( ( position=str.find(c,position) ) != string::npos ) {
		cout<< "position " << i << ": " << position + 1 << endl;
		position++;
		i++;
	}
	return 0;

}
