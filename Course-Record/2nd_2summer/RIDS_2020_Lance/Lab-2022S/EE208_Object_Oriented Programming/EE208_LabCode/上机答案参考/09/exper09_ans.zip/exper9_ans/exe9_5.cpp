/**
 * Count the number of occurrences of a substring in a string.
 * 
 * Input format.
 * The length of the input string should not exceed 100, and the substring should not exceed the original string.
 * 
 * Output format.
 * The number of the substring.
 * 
 * input.
 * I have a pen, I have an apple, Apple,pen.
 * apple
 * 
 * output.
 * The number of substrings is 1
 */

#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
int main()
{
	char str[100]; // str
	int len1, len2;
	cout <<  "input a string��" << endl;
	gets(str);
	len1 = strlen(str); //length of str
	char substr[100];
	cout <<  "input a substring��" << endl;
	gets(substr);
	len2 = strlen(substr);//length of substr
	
	int n = 0, sum = 0; //sum is accumulator
	
	// The outer loop is used to traverse the array
	for (int i = 0; i <= len1-len2; i++)
	{
		// The k defined here and the n above are for the protection of the site
		int k = 0, s = 0; // s is a counter
		n = i;
		for (int j = 0; j < len2; j++)
		{
			if (str[n] == substr[k]) // If they are the same, then compare the next letter
			{
				n++;
				k++;
				s++; // If the letters are the same, s increments once
			}
			else // If not, repeat the next cycle
			{
				break;
			}
		}
		if (s == len2)
		{
			// If the number of letters in the substring that are identical to the original string 
			// is equal to the length of the substring, then this is one of the substrings
			sum++;
		}
	}
	cout << "The number of substrings is " << sum <<endl;
	return 0;
}

