/**
 * Count the number of occurrences of each letter of the input string, case - insensitive.
 * 
 * Input format
 * The input is a string containing only 26 English letters, and the length of the string is not more than 100.
 * 
 * Output format
 * Output the number of occurrences of each letter.
 * 
 * Input:
 * Supercaliocious
 * 
 * Output:
 * the number of a : 1
 * the number of c : 2
 * the number of e : 1
 * the number of i : 2
 * the number of l : 1
 * the number of o : 2
 * the number of p : 1
 * the number of r : 1
 * the number of s : 2
 * the number of u : 2
 */

#include <iostream>
#include <string>
using namespace std;
int num[26]; // 0 to 25 corresponds to the number of occurrences of a to z
int main() {
	string data;
	int index = -1;
	char c;
	cout<< "please input a string" << endl;
	// input string
	cin >> data;
	// Statistical frequency of occurrence
	for(int i = 0; i < data.size(); i++) {
		if(data[i] >= 'a' && data[i] <= 'z')
			index = data[i] - 'a';
		else if(data[i] >= 'A' && data[i] <= 'Z')
			index = data[i] - 'A';
		if(index != -1)
			num[index]++;
		index = -1;
	}
	// output
	for(int j = 0; j < 26; j++) { 
		if(num[j] != 0) {
			c= 'a' + j;
			cout << "the number of " << c << " : " << num[j] << endl;
		}
	}
	return 0;
}
