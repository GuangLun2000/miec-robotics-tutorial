/**
 * Enter a string and print whether the string is a palindrome. A palindrome is a string that reads the 
 * same backwards and forwards.
 * 
 * Input format.
 * Input as a string (no whitespace characters in the string, string length less than 100).
 * 
 * Output format.
 * If the string is a palindrome, print yes;Otherwise, output no.
 * 
 * Input1:
 * abcdedcba
 * Output1:
 * yes
 * Input2:
 * agg
 * Output2:
 * no
 */

#include<iostream>
#include<string>
using namespace std;
int main()
{
    string s;
    cin >> s;
    int flag = 0;
    for(int i = 0, j = s.size() - 1; i < j; i++, j--){
        if(s[i] == s[j])
            continue;
        else
            flag=1;
    }
    if(flag)
        cout << "no" << endl;
    else
        cout << "yes" << endl;
    return 0;
}

