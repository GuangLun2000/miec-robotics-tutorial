#include<iostream>
using namespace std;

int main(){
	
	double time, salary;
	cout << "Please input working hours:"; 
	cin >> time;
	if(time <= 40 && time >= 0){
		salary = time * 12;
	}else if(time >40){
		salary = 480 + (time - 40) * 17;
	}else{
		cout << "Error!" << endl;
		return 0;
	}
	cout << salary << endl;
	
	
} 
