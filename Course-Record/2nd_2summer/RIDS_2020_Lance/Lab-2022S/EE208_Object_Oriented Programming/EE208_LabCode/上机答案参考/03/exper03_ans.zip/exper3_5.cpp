#include<iostream>
using namespace std;

int main(){
	
	int a, b, code;
	cout << "Please input three numbers:";
	cin >> a >> b >> code;
	
	if(code == 1){
		cout << a + b << endl;
	}else if(code == 2){
		cout << a * b << endl;
	}else if(code == 3){
		if(b == 0){
			cout << "Error!" << endl;
			return 0;
		}else{
			cout << (double)a / b << endl;
		}
	}else{
		cout << "Error code!" << endl;
	}
	
	
	return 0;
}
