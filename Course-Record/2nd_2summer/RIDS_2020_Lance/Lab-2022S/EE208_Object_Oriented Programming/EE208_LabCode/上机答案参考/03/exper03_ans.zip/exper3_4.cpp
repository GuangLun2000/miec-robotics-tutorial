#include<iostream>
using namespace std;

int main(){
	
	int a, b, c, ans;
	cout << "Please input three numbers:";
	cin >> a >> b >> c;
	
	if(a < 0||a > 13||b < 0||b > 13||c < 0||c > 13){
		cout << "Error!" << endl;
		return 0; 
	}
	
	if(a > 10)
		a = 10;
	if(b > 10)
		b = 10;
	if(c > 10)
		c = 10;
	
	if(a == 1||b == 1||c == 1){
		if(a + b + c + 10 <= 21){
			ans = a + b + c + 10;
		}else{
			ans = a + b + c;
		}
	}else{
		ans = a + b + c;
	}
	cout << ans << endl;
	
	
	return 0;
}
