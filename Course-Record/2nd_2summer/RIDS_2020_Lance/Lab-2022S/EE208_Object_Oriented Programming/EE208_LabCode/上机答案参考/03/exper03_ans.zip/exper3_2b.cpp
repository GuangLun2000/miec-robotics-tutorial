#include<iostream>
using namespace std;

int main(){
	
	int a, b;
	cout << "Please input two numbers:";
	cin >> a;
	cin >> b;
	if(a % b ==0){
		cout << "Yes";
	}else{
		cout << "No";
	}
	return 0;
}
