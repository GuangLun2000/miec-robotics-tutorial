#include<stdio.h>
#include<iostream>
using namespace std;
const float PI=3.1416;

//c = 2πr, where r is the radius and π equals 3.1416

int main(){

    float radius = 3.3;
    float circumference = 2*PI*radius;

    cout << "Circumference =  " << circumference << endl;
    return 0;
}

//this code is created by Lance Cai 832002117