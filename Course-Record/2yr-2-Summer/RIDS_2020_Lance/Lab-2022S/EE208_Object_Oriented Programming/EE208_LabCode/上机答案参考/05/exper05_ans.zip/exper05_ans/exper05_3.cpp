#include<iostream>
using namespace std;
int f(int min, int max)
{
	int i = 0;
	int s = 0;
	if (max < min)
		return 0;
	else
	{
		for (i = min; i <= max; i++)
		{
			if (i % 2 == 1)
				s += i;
		}
		return s;
	}
}
int main()
{
	int i, j, m, n, max = 0;
	cin >> j;
	for (i = 0; i < j; i++)
	{
		cin >> m >> n;
		if (f(m, n) > max)
			max = f(m, n);
	}
	cout << max << endl;
	return 0;
}