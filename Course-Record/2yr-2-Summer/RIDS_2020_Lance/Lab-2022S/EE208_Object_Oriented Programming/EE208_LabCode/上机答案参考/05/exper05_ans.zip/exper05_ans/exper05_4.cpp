#include<iostream>
using namespace std;
int f(int a, int i)
{
	int s = 0;
	for (int j = 0; j < i; j++)
	{
		s = s * 10 + a;
	}
	return s;
}
int main()
{
	int a, i, n, j;
	cin >> a >> n;
	int s = 0;
	for (i = 1; i <= n; i++)
	{
		s += f(a, i);
	}
	cout << s << endl;
	return 0;
}