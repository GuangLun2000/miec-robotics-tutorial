#include<iostream>
using namespace std;

int maxProfit(int prices[], int n) {
    int ans = 0, minPrice = 0;
    for (int i = 0; i < n; i++) {
        if(i == 0) {
            minPrice = prices[i];
        } else if (prices[i] < minPrice) {
            minPrice = prices[i];
        } else {
            ans = max(ans, prices[i] - minPrice);   // ���������нϴ��ֵ 
        }
    }
    return ans;
}

int main()
{
	int n, price[10000];
	cin >> n;
	for (int i = 0; i < n; i++) cin >> price[i];
	cout << maxProfit(price, n) << endl;
}
