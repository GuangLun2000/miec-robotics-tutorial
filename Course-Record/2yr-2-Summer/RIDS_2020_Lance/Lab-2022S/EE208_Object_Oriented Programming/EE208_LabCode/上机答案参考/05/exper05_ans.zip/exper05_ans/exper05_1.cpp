#include<iostream>
using namespace std;

int firstUniqChar(char str[], int n) 
{
	int map[26] = { 0 };
	for (int i = 0; i < n; i++) map[str[i] - 'a']++;
	for(int i = 0; i < n; i++) if (map[str[i] - 'a'] == 1) return i;
	return -1;
}

int main() 
{
	int n;
	char str[500];
	cin >> n >> str;
	cout << firstUniqChar(str, n) << endl;
}
