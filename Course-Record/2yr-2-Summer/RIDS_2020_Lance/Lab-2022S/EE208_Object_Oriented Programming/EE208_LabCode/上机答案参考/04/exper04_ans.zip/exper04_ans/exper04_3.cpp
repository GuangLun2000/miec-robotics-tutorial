#include<iostream>
using namespace std;
int main()
{
	int count=10;
	double gallon,liters;
	while(count>0){
		cin>>gallon;
		liters = 3.785 * gallon;
		cout<<liters<<endl;
		count--;
	} 
	return 0;
}
