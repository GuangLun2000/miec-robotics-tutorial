#include<iostream>
using namespace std;
int main()
{
	int x,z;
	double y;
	for(x=1;x<=5;x++)
	{
		for(z=2;z<=6;z++)
		{
			if(x==z)
			{
			   cout<<"Function Undefined"<<endl;
			   continue;
			}
			y=x*z/(x-z);
			cout<<y<<endl;
		}
	}
	return 0;
}
