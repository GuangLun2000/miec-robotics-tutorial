#include<iostream>
#include <stdlib.h>
#include<ctime>
using namespace std;
int main()
{
	int count=0;
	int random;
	int inputNum;
	srand(time(NULL));
	random = rand()%200;
	cout<<"Please input a number between 1 and 200 to guess the value"<<endl;
	while(count<7){
		cin>>inputNum;
		count++;
		if(inputNum == random){
			cout<<"Congratulations. Bingo! You have guessed right by "<<count<<" times"<<endl;
			break;
		}else if(inputNum>random){
				cout<<"Unfortunately, your guess was too high. Please input another number to guess"<<endl;
		   	}else {
		   		cout<<"Unfortunately, your guess was too low. Please input another number to guess"<<endl;
			   }
	}
	return 0;
}
