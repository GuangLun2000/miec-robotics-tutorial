#include<iostream>
using namespace std;
int main()
{
	int n,i,result=1;
	cin>>n;
	for(i=0;i<n;i++){
		result=2*result;
	}
	cout<<result<<endl;
	return 0;
}
