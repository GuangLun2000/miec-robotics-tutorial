#include<iostream>
using namespace std;
int main()
{
	for(char i='Z';i>='A';--i)
	{
		    cout<<i<<" ";
	} 
	cout<<endl;
	return 0;
}
