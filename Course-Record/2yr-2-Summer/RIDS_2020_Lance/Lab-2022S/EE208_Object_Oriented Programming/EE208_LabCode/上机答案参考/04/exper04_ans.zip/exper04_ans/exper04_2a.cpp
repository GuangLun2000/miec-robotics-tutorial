#include<iostream>
using namespace std;
int main()
{
	for(int i=33;i>=3;--i)
	{
		if(i%3==0) 
		    cout<<i<<" ";
	} 
	cout<<endl;
	return 0;
}
