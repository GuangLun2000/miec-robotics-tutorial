#include<iostream>
using namespace std;

void markElement(int mat[][10],int mark[][10],int r, int c);
void transform(int mat[][10],int mark[][10], int r,int c);

int main(){
	int r,c;
	int mat[10][10]; int mark[10][10];
	for(int i=0;i<r;i++)
		for(int j=0;j<c;j++)
			mark[i][j]=0;
		
	cin>>r>>c;
	for(int i=0;i<r;i++)
		for(int j=0;j<c;j++)
			cin>>mat[i][j];
	
	markElement(mat,mark,r,c);
	transform(mat,mark,r,c);
	
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			cout<<mat[i][j]<<" ";
		}
		cout<<endl;
	}
	return 0;
}
// Find out 'zero point' and mark them by a array.
void markElement(int mat[][10],int mark[][10],int r, int c){
	for(int i=0;i<r;i++)
		for(int j=0;j<c;j++){
			if(mat[i][j]==0){
				mark[i][j]=1;
			}
		}
	return ;
}
// Change the other elements to zero which are in the same column or in the same row with 'zero point'.
void transform(int mat[][10], int mark[][10], int r,int c){
	for(int i=0;i<r;i++)
		for(int j=0;j<c;j++){
			if(mark[i][j]==1){
				for(int k=0;k<c;k++){
					mat[i][k]=0;
				}
				
				for(int k=0;k<r;k++){
					mat[k][j]=0;
				}
			}
		}
	return;
}
