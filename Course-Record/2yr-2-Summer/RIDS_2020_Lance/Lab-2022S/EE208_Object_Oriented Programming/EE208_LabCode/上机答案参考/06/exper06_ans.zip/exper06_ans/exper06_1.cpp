#include <iostream>
using namespace std;

int secondMax(int arr[], int length);

int main() {
	int arr[110],length;
	int temp,index=0;

	// Input a non-empty array of positive integers from keyboard.
	while(cin>>temp) {
		if(temp < 0 )
			break;
		arr[index++] = temp;
	}
	length = index;

	// Get the second maximum in the array.
	int ans = secondMax(arr,length);

	cout << ans << endl;
	return 0;
}

int secondMax(int arr[],int length) {
	int memory[2] = {-1, -1};
	for(int i = 0; i < length; i++) {
		if(arr[i] == memory[0] || arr[i] == memory[1])
			continue;
		if(arr[i] > memory[1]) {
			memory[0] = memory[1];
			memory[1] = arr[i];
		} else if(arr[i] > memory[0]) {
			memory[0] = arr[i];
		}
	}
	for(int i = 0; i < length; i++) {
		if(memory[i] == -1)
			return -1;
	}
	return memory[0];
}


/**
	Why not have a try at using vector?

#include <vector>
#include <iostream>
using namespace std;

//	@param nums: the array
//	@return: the second maximum number in this array
int secondMax(vector<int> &nums) {
	vector<long> memory(2, LONG_MIN);
	for(int i = 0; i < nums.size(); i++) {
		if(nums[i] == memory[0] || nums[i] == memory[1])
			continue;
		if(nums[i] > memory[1]) {
			memory[0] = memory[1];
			memory[1] = nums[i];
		} else if(nums[i] > memory[0]) {
			memory[0] = nums[i];
		}
	}
	for(int i = 0; i < memory.size(); i++) {
		if(memory[i] == LONG_MIN)
			return -1;
	}
	return memory[0];
}

int main() {
	vector<int> num;
	int temp;
	while(true) {
		cin>>temp;
		if(temp < 0)
			break;
		num.push_back(temp);
	}

	// Get the second maximum in the array.
	int ans = secondMax(num);

	cout << ans << endl;
	return 0;
}
*/
