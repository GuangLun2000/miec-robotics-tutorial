#include<iostream>
#include<vector>
using namespace std;

int minPos(vector<int> vec);

int main(){
	vector<int> vec;
	int temp;
	while(true){
		cin>>temp;
		if(temp<0)
			break;
		vec.push_back(temp);
	}
	int ans = minPos(vec);
	cout<<ans<<endl;
}

int minPos(vector<int> vec){
	int pos=1; 
	int min=vec.at(0);
	for(int i=0;i<vec.size();i++){
		if(min>vec[i]){
			min = vec[i];
			pos=i+1;
		}
	}
	
	return pos;
}
