#include<iostream>
using namespace std;

void rotate(int nums[], int length, int m);

int main() {
	int arr[7];
	int m;
	cout<<"Please input seven array elements."<<endl;
	
	for(int i=0;i<7;i++){
		cin>>arr[i];
	}
	
	cout<<"Please input m."<<endl;
	cin>>m;
	
	rotate(arr,7,m);
	
	cout<<"The new rotated array is shown below:"<<endl;
	for(int i=0;i<6;i++){
		cout<<arr[i]<<" ";
	}
	cout<<arr[6]<<endl;
	
	return 0;
}

/**
 * @param nums: an array
 * @param m: an integer
 * @return: rotate the array to the left by m steps
 */
void rotate(int nums[],int length, int m) {
	if(m < 0) {
		return ;
	}

	m = m % length;
	int steps = length - m;
	int ans[length];
	int j = length - 1;
	for(int i = m-1; i >= 0; i--) {
		ans[j--] = nums[i];
	}

	for(int i = length-1; i >= m; i --) {
		ans[j--] = nums[i];
	}

	for(int i=0; i<length; i++){
		nums[i]=ans[i];
	}
	
	return ;
}

