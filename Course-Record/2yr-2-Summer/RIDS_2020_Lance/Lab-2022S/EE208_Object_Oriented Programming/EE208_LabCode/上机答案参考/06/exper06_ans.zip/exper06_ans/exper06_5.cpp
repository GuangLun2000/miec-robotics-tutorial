#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	int arr[100];
	int temp,index=0,length=0;
	while(true){
		cin>>temp;
		if(temp<0)
			break;
		arr[index++]=temp;
		length++;
	}
	
	sort(arr,arr+length);
	
	for(int i=0;i<length;i++){
		cout<<arr[i]<<" ";
	}
}
